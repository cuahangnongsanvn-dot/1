# Match-3 Smart Bot for J2ME Loader

Ứng dụng Android tự động chơi game xếp ngọc đối kháng phong cách J2ME RPG với trí tuệ nhân tạo và điều khiển qua phím ảo T9.

## Tính Năng Nổi Bật
- **Điều khiển qua cụm phím điều hướng (T9):** Nhận diện khung viền xanh lục bảo và gửi phím Lên, Xuống, Trái, Phải, F để chọn ngọc không lo trượt tay cảm ứng.
- **Tự động xả Xích Lôi Công:** Tích cực ăn Bát quái gom Mana, vừa chạm vạch là tự bấm `L` -> `F` -> `L` kích hoạt sấm sét nổ 12 ô cờ.
- **Chiến thuật đối kháng Minimax:**
  - Tuyệt đối ưu tiên Match-4+ để giành thêm lượt đi liên tiếp.
  - Phân tích nước đi tránh dâng mồi ngon (Kiếm, Match-4) cho quái vật ở lượt sau.
- **Chống phát hiện (Anti-bot):** Tạo độ trễ ngẫu nhiên 140ms - 220ms giữa mỗi lần bấm phím hệt như ngón tay người bấm.

## Hướng Dẫn Build APK Trên GitHub
1. Tải toàn bộ mã nguồn này lên một kho lưu trữ (repository) mới trên GitHub.
2. Vào mục **Actions** trên GitHub, bạn sẽ thấy tiến trình **Build Game Bot APK** tự động chạy.
3. Khi hoàn tất, tải file APK từ mục **Artifacts** về máy điện thoại Android để cài đặt.
