package com.gamebot.match3

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

/**
 * Quản lý gửi cử chỉ chạm vào cụm phím ảo T9 của J2ME Loader:
 * - Điều khiển tiêu điểm qua các phím mũi tên.
 * - Nhấn F để chọn ngọc và hoán đổi.
 * - Nhấn chuỗi L -> F -> L để xả Xích Lôi Công khi đầy Mana.
 * - Tự động chèn độ trễ ngẫu nhiên mô phỏng ngón tay người thật.
 */
class KeypadController(private val service: AccessibilityService) {

    private val handler = Handler(Looper.getMainLooper())

    data class PointF(val x: Float, val y: Float)

    /**
     * Tọa độ các phím ảo ở nửa dưới màn hình giả lập J2ME Loader
     */
    fun getKeypadPositions(screenWidth: Int, screenHeight: Int): Map<String, PointF> {
        val padTop = screenHeight * 0.70f
        val padBottom = screenHeight * 0.98f
        val padHeight = padBottom - padTop
        val colWidth = screenWidth / 6f
        val rowHeight = padHeight / 4f

        return mapOf(
            "SOFT_LEFT" to PointF(colWidth * 3.5f, padTop + rowHeight * 0.5f), // Phím L
            "UP"        to PointF(colWidth * 4.5f, padTop + rowHeight * 1.5f), // Phím ↑
            "DOWN"      to PointF(colWidth * 4.5f, padTop + rowHeight * 3.5f), // Phím ↓
            "LEFT"      to PointF(colWidth * 3.5f, padTop + rowHeight * 2.5f), // Phím ←
            "RIGHT"     to PointF(colWidth * 5.5f, padTop + rowHeight * 2.5f), // Phím →
            "FIRE"      to PointF(colWidth * 4.5f, padTop + rowHeight * 2.5f)  // Phím F (Chọn)
        )
    }

    /**
     * Quét tìm tọa độ (r, c) đang có viền xanh lục bảo bao bọc
     */
    fun findEmeraldCursor(bitmap: Bitmap, boardLeft: Int, boardTop: Int, cellW: Int, cellH: Int): Pair<Int, Int>? {
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                // Kiểm tra điểm trên mép viền của từng ô cờ
                val checkX = boardLeft + c * cellW + cellW / 2
                val checkY = boardTop + r * cellH + 4

                if (checkX < bitmap.width && checkY < bitmap.height) {
                    val pixel = bitmap.getPixel(checkX, checkY)
                    val hsv = FloatArray(3)
                    Color.RGBToHSV(Color.red(pixel), Color.green(pixel), Color.blue(pixel), hsv)

                    // Viền xanh lục bảo/cyan: Hue khoảng 155 - 190 độ, Saturation > 0.55
                    if (hsv[0] in 155f..190f && hsv[1] > 0.55f && hsv[2] > 0.45f) {
                        return Pair(r, c)
                    }
                }
            }
        }
        return null
    }

    /**
     * Di chuyển tiêu điểm từ vị trí hiện tại đến ô ngọc, nhấn F và gạt sang ô kề cạnh
     */
    fun executeMoveWithKeys(
        currentPos: Pair<Int, Int>,
        targetFrom: Pair<Int, Int>,
        targetTo: Pair<Int, Int>,
        keyPositions: Map<String, PointF>,
        onFinished: () -> Unit
    ) {
        val keySequence = mutableListOf<PointF>()

        // 1. Di chuyển tiêu điểm đến ô thứ nhất
        val dRow = targetFrom.first - currentPos.first
        val dCol = targetFrom.second - currentPos.second

        val vKey = if (dRow > 0) keyPositions["DOWN"] else keyPositions["UP"]
        repeat(Math.abs(dRow)) { vKey?.let { keySequence.add(it) } }

        val hKey = if (dCol > 0) keyPositions["RIGHT"] else keyPositions["LEFT"]
        repeat(Math.abs(dCol)) { hKey?.let { keySequence.add(it) } }

        // 2. Nhấn phím F để chọn ô
        keyPositions["FIRE"]?.let { keySequence.add(it) }

        // 3. Nhấn mũi tên hướng sang ô thứ hai để thực hiện hoán đổi
        val swapRow = targetTo.first - targetFrom.first
        val swapCol = targetTo.second - targetFrom.second

        when {
            swapRow == 1  -> keyPositions["DOWN"]?.let { keySequence.add(it) }
            swapRow == -1 -> keyPositions["UP"]?.let { keySequence.add(it) }
            swapCol == 1  -> keyPositions["RIGHT"]?.let { keySequence.add(it) }
            swapCol == -1 -> keyPositions["LEFT"]?.let { keySequence.add(it) }
        }

        // Bấm chuỗi phím tuần tự có giãn cách tự nhiên
        pressKeySequence(keySequence, 0, onFinished)
    }

    /**
     * Tự động bấm chuỗi L -> F -> L để xả chiêu Xích Lôi Công khi đầy Mana
     */
    fun castSkill1(keyPositions: Map<String, PointF>, onDone: () -> Unit) {
        val softLeft = keyPositions["SOFT_LEFT"] ?: return
        val fire = keyPositions["FIRE"] ?: return

        // 1. Nhấn L (Mở Menu Tuyệt Chiêu)
        tapKey(softLeft.x, softLeft.y) {
            handler.postDelayed({
                // 2. Nhấn F (Vào chọn Xích Lôi Công)
                tapKey(fire.x, fire.y) {
                    handler.postDelayed({
                        // 3. Nhấn L (Xác nhận "Dùng")
                        tapKey(softLeft.x, softLeft.y) {
                            // Đợi hiệu ứng sấm sét nổ xong (khoảng 2.4s)
                            handler.postDelayed({
                                onDone()
                            }, 2400)
                        }
                    }, 220)
                }
            }, 220)
        }
    }

    private fun pressKeySequence(sequence: List<PointF>, index: Int, onComplete: () -> Unit) {
        if (index >= sequence.size) {
            onComplete()
            return
        }

        val target = sequence[index]
        tapKey(target.x, target.y) {
            // Giãn cách ngẫu nhiên 140ms - 220ms giữa các lần bấm phím để giả lập người thật
            val delay = Random.nextLong(140, 220)
            handler.postDelayed({
                pressKeySequence(sequence, index + 1, onComplete)
            }, delay)
        }
    }

    private fun tapKey(x: Float, y: Float, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val pressDuration = Random.nextLong(50, 85)
        val stroke = GestureDescription.StrokeDescription(path, 0, pressDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = done()
            override fun onCancelled(gestureDescription: GestureDescription?) = done()
        }, null)
    }
}
