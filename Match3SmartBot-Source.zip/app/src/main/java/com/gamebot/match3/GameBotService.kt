package com.gamebot.match3

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class GameBotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private lateinit var keyController: KeypadController

    companion object {
        var instance: GameBotService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        keyController = KeypadController(this)
        Toast.makeText(this, "Game Bot Service đã kích hoạt sẵn sàng!", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        isRunning = false
    }

    fun startAuto() {
        if (isRunning) return
        isRunning = true
        Toast.makeText(this, "Bắt đầu tự động đánh thông minh...", Toast.LENGTH_SHORT).show()
        loopTurn()
    }

    fun stopAuto() {
        isRunning = false
        Toast.makeText(this, "Đã dừng Bot.", Toast.LENGTH_SHORT).show()
    }

    fun isBotRunning(): Boolean = isRunning

    private fun loopTurn() {
        if (!isRunning) return

        takeScreenshot(Display.DEFAULT_DISPLAY, applicationContext.mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                    ?.copy(Bitmap.Config.ARGB_8888, false)
                screenshot.hardwareBuffer.close()

                if (bitmap != null) {
                    processScreen(bitmap)
                } else {
                    retryNext(1000)
                }
            }

            override fun onFailure(errorCode: Int) {
                retryNext(1500)
            }
        })
    }

    private fun processScreen(bitmap: Bitmap) {
        val width = bitmap.width
        val height = bitmap.height

        // Căn chỉnh tọa độ vùng bàn cờ 8x8 (theo tỉ lệ chuẩn màn hình game trong video)
        val boardLeft = (width * 0.05f).toInt()
        val boardRight = (width * 0.95f).toInt()
        val boardTop = (height * 0.09f).toInt()
        val boardBottom = (height * 0.52f).toInt()

        val cellW = (boardRight - boardLeft) / 8
        val cellH = (boardBottom - boardTop) / 8

        val keyPositions = keyController.getKeypadPositions(width, height)

        // 1. Kiểm tra xem có đang là lượt của mình không (quét tìm viền xanh lục bảo)
        val cursor = keyController.findEmeraldCursor(bitmap, boardLeft, boardTop, cellW, cellH)
        if (cursor == null) {
            // Chưa có tiêu điểm (game đang chạy animation hoặc lượt quái đánh) -> Đợi tiếp
            retryNext(800)
            return
        }

        // 2. Kiểm tra thanh MANA (Thanh dưới bên trái, ngay dưới bàn cờ)
        val checkManaX = (width * 0.30f).toInt()
        val checkManaY = (height * 0.54f).toInt()

        val manaPixel = bitmap.getPixel(checkManaX, checkManaY)
        val manaHsv = FloatArray(3)
        Color.RGBToHSV(Color.red(manaPixel), Color.green(manaPixel), Color.blue(manaPixel), manaHsv)

        // Khi Mana đầy, thanh sáng màu xanh lục (Hue từ 85 đến 150, Saturation > 0.45)
        val isManaFull = (manaHsv[0] in 85f..150f && manaHsv[1] > 0.45f && manaHsv[2] > 0.45f)

        if (isManaFull) {
            // ĐỦ MANA -> BỎ QUA XẾP CỜ, XẢ NGAY XÍCH LÔI CÔNG
            keyController.castSkill1(keyPositions) {
                retryNext(1200)
            }
            return
        }

        // 3. Quét màu tâm của từng ô cờ để nhận diện 7 loại ngọc
        val board = Array(8) { IntArray(8) }
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val centerX = boardLeft + c * cellW + cellW / 2
                val centerY = boardTop + r * cellH + cellH / 2

                if (centerX < width && centerY < height) {
                    val pixel = bitmap.getPixel(centerX, centerY)
                    board[r][c] = identifyGem(pixel)
                }
            }
        }

        // 4. Kiểm tra thanh máu nhân vật (để ưu tiên tim nếu HP thấp)
        val hpCheckX = (width * 0.15f).toInt()
        val hpCheckY = (height * 0.53f).toInt()
        val hpPixel = bitmap.getPixel(hpCheckX, hpCheckY)
        val hpHsv = FloatArray(3)
        Color.RGBToHSV(Color.red(hpPixel), Color.green(hpPixel), Color.blue(hpPixel), hpHsv)
        val isHpLow = !(hpHsv[0] in 330f..360f || hpHsv[0] in 0f..20f) // Mất vạch đỏ hồng

        // 5. Tính toán nước đi thông minh nhất
        val bestMove = BoardSolver.findBestMove(board, isMyHpLow = isHpLow, needsMana = !isManaFull)

        if (bestMove != null) {
            val targetFrom = Pair(bestMove.r1, bestMove.c1)
            val targetTo = Pair(bestMove.r2, bestMove.c2)

            keyController.executeMoveWithKeys(cursor, targetFrom, targetTo, keyPositions) {
                // Đợi hiệu ứng nổ ngọc và rơi ổn định rồi mới quét tiếp
                retryNext(1400)
            }
        } else {
            // Không quét thấy nước rõ ràng, đợi 1 giây quét lại
            retryNext(1000)
        }
    }

    /**
     * Nhận diện loại ngọc dựa trên phân tích màu HSV tại tâm viên ngọc
     */
    private fun identifyGem(pixel: Int): Int {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)

        val hsv = FloatArray(3)
        Color.RGBToHSV(r, g, b, hsv)
        val hue = hsv[0]
        val sat = hsv[1]
        val value = hsv[2]

        return when {
            sat < 0.22f -> BoardSolver.SWORD          // Kiếm: Màu ánh bạc/trắng ít bão hòa
            hue in 80f..145f -> BoardSolver.STAR     // Sao: Xanh lá lục
            hue in 310f..355f -> BoardSolver.HEART   // Tim: Đỏ hồng
            hue in 35f..65f -> BoardSolver.GOLD      // Vàng: Vàng kim
            hue in 180f..230f -> BoardSolver.BAGUA   // Bát quái: Xanh dương / Cyan (Mana)
            hue in 260f..305f -> BoardSolver.DROP    // Giọt nước: Tím
            else -> BoardSolver.PEACH                // Đào: Hồng cam
        }
    }

    private fun retryNext(delayMs: Long) {
        handler.postDelayed({ loopTurn() }, delayMs)
    }

    override fun onDestroy() {
        isRunning = false
        instance = null
        super.onDestroy()
    }
}
