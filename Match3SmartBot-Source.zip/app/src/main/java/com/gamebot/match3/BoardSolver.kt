package com.gamebot.match3

/**
 * Bộ não tính toán chiến thuật đối kháng cho bàn cờ 8x8:
 * - Ưu tiên Match-4+ để cướp lượt đi liên hoàn.
 * - Ưu tiên Bát quái (BAGUA) để tích Mana xài Xích Lôi Công.
 * - Ưu tiên Kiếm (SWORD) dồn sát thương khi đã đầy mana.
 * - Phòng thủ: Trừ điểm nếu nước đi để lại thế Match-4 hoặc Kiếm cho quái ăn.
 */
object BoardSolver {
    const val EMPTY = 0
    const val SWORD = 1   // Kiếm: Sát thương trừ máu quái
    const val HEART = 2   // Tim: Hồi phục sinh mệnh
    const val BAGUA = 3   // Bát quái (Âm dương): Nạp MANA dùng tuyệt chiêu
    const val STAR  = 4   // Sao xanh: Điểm kinh nghiệm (EXP)
    const val GOLD  = 5   // Vàng
    const val PEACH = 6   // Đào
    const val DROP  = 7   // Giọt tím

    data class Move(val r1: Int, val c1: Int, val r2: Int, val c2: Int, val score: Int)

    fun findBestMove(board: Array<IntArray>, isMyHpLow: Boolean = false, needsMana: Boolean = true): Move? {
        var bestMove: Move? = null
        var maxNetScore = Int.MIN_VALUE

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                // Thử hoán đổi với ô bên phải
                if (c + 1 < 8) {
                    val score = evaluateMinimaxMove(board, r, c, r, c + 1, isMyHpLow, needsMana)
                    if (score > maxNetScore) {
                        maxNetScore = score
                        bestMove = Move(r, c, r, c + 1, score)
                    }
                }
                // Thử hoán đổi với ô bên dưới
                if (r + 1 < 8) {
                    val score = evaluateMinimaxMove(board, r, c, r + 1, c, isMyHpLow, needsMana)
                    if (score > maxNetScore) {
                        maxNetScore = score
                        bestMove = Move(r, c, r + 1, c, score)
                    }
                }
            }
        }
        return if (maxNetScore > 0) bestMove else null
    }

    private fun evaluateMinimaxMove(
        board: Array<IntArray>,
        r1: Int, c1: Int, r2: Int, c2: Int,
        isMyHpLow: Boolean,
        needsMana: Boolean
    ): Int {
        val t1 = board[r1][c1]
        val t2 = board[r2][c2]
        if (t1 == EMPTY || t2 == EMPTY || t1 == t2) return Int.MIN_VALUE

        // 1. Giả lập hoán đổi
        board[r1][c1] = t2
        board[r2][c2] = t1

        val match1 = getMatchSize(board, r1, c1)
        val match2 = getMatchSize(board, r2, c2)
        val maxMyMatch = maxOf(match1, match2)

        if (maxMyMatch < 3) {
            board[r1][c1] = t1
            board[r2][c2] = t2
            return Int.MIN_VALUE
        }

        var myGain = 0
        val gemType = if (match1 >= 3) board[r1][c1] else board[r2][c2]

        // QUY TẮC 1: ĂN 4+ TRỞ LÊN ĐƯỢC THÊM LƯỢT (CƯỚP LƯỢT QUÁI)
        if (maxMyMatch >= 4) {
            myGain += 40000 + (maxMyMatch - 4) * 10000
        }

        // QUY TẮC 2: PHÂN BỔ ĐIỂM THEO LOẠI NGỌC CHIẾN LƯỢC
        myGain += when (gemType) {
            BAGUA -> if (needsMana) 10000 else 800  // Ưu tiên cao nhất khi cần mana
            HEART -> if (isMyHpLow) 8000 else 900   // Thấp máu thì cứu mạng
            SWORD -> if (!needsMana) 4000 else 2000 // Chém quái khi đã nạp đủ mana
            STAR, GOLD, PEACH, DROP -> 250          // Ngọc phụ trợ
            else -> 100
        }

        // Ưu tiên ăn các hàng ở dưới đáy (r = 5, 6, 7) để kích hoạt hiệu ứng thác đổ (cascade)
        myGain += maxOf(r1, r2) * 50

        // QUY TẮC 3: PHÒNG THỦ MINIMAX (Nếu không được thêm lượt, kiểm tra quái có ăn được thế ngon không)
        var enemyThreat = 0
        if (maxMyMatch < 4) {
            enemyThreat = scanBestEnemyThreat(board)
        }

        // Trả lại bàn cờ ban đầu
        board[r1][c1] = t1
        board[r2][c2] = t2

        return myGain - enemyThreat
    }

    private fun scanBestEnemyThreat(b: Array<IntArray>): Int {
        var highestThreat = 0
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                if (c + 1 < 8) highestThreat = maxOf(highestThreat, checkSimpleSwapThreat(b, r, c, r, c + 1))
                if (r + 1 < 8) highestThreat = maxOf(highestThreat, checkSimpleSwapThreat(b, r, c, r + 1, c))
            }
        }
        return highestThreat
    }

    private fun checkSimpleSwapThreat(b: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int): Int {
        val t1 = b[r1][c1]
        val t2 = b[r2][c2]
        if (t1 == EMPTY || t2 == EMPTY || t1 == t2) return 0

        b[r1][c1] = t2
        b[r2][c2] = t1

        val m1 = getMatchSize(b, r1, c1)
        val m2 = getMatchSize(b, r2, c2)
        val maxM = maxOf(m1, m2)

        var threat = 0
        if (maxM >= 3) {
            val gem = if (m1 >= 3) b[r1][c1] else b[r2][c2]
            threat = if (maxM >= 4) 18000 else 0
            threat += when (gem) {
                SWORD -> 4000 // Quái chém kiếm sát thương rất thốn
                BAGUA -> 2500 // Quái tích mana
                else -> 500
            }
        }

        b[r1][c1] = t1
        b[r2][c2] = t2
        return threat
    }

    private fun getMatchSize(b: Array<IntArray>, r: Int, c: Int): Int {
        val type = b[r][c]
        if (type == EMPTY) return 0

        var horiz = 1
        var left = c - 1
        while (left >= 0 && b[r][left] == type) { horiz++; left-- }
        var right = c + 1
        while (right < 8 && b[r][right] == type) { horiz++; right++ }

        var vert = 1
        var up = r - 1
        while (up >= 0 && b[up][c] == type) { vert++; up-- }
        var down = r + 1
        while (down < 8 && b[down][c] == type) { vert++; down++ }

        return maxOf(if (horiz >= 3) horiz else 0, if (vert >= 3) vert else 0)
    }
}
