package com.gamebot.match3

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var tvServiceStatus: TextView
    private lateinit var tvBotState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvServiceStatus = findViewById(R.id.tvServiceStatus)
        tvBotState = findViewById(R.id.tvBotState)

        val btnAccessibility = findViewById<MaterialButton>(R.id.btnAccessibility)
        val btnStartBot = findViewById<MaterialButton>(R.id.btnStartBot)
        val btnStopBot = findViewById<MaterialButton>(R.id.btnStopBot)

        btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnStartBot.setOnClickListener {
            val service = GameBotService.instance
            if (service != null) {
                service.startAuto()
                updateUIState()
                // Tự động thu nhỏ màn hình app để hiển thị game ngay lập tức
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "Bạn cần bật quyền Trợ Năng (Accessibility) trước!", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        btnStopBot.setOnClickListener {
            GameBotService.instance?.stopAuto()
            updateUIState()
        }
    }

    override fun onResume() {
        super.onResume()
        updateUIState()
    }

    private fun updateUIState() {
        val service = GameBotService.instance
        if (service != null) {
            tvServiceStatus.text = "Trạng thái dịch vụ: ĐÃ BẬT SẴN SÀNG"
            tvServiceStatus.setTextColor(Color.parseColor("#00E676"))

            if (service.isBotRunning()) {
                tvBotState.text = "Trạng thái Bot: ĐANG TỰ ĐỘNG ĐÁNH"
                tvBotState.setTextColor(Color.parseColor("#00E676"))
            } else {
                tvBotState.text = "Trạng thái Bot: Đang tạm dừng"
                tvBotState.setTextColor(Color.parseColor("#B0B0B0"))
            }
        } else {
            tvServiceStatus.text = "Trạng thái dịch vụ: CHƯA BẬT (Cần cấp quyền)"
            tvServiceStatus.setTextColor(Color.parseColor("#FF5252"))
            tvBotState.text = "Trạng thái Bot: Chưa sẵn sàng"
            tvBotState.setTextColor(Color.parseColor("#B0B0B0"))
        }
    }
}
